package org.testng.internal.annotations;

public interface IAfterTest extends IBaseBeforeAfter {

}
