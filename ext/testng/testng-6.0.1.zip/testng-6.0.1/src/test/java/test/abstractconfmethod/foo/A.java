package test.abstractconfmethod.foo;

public abstract class A
{
   public abstract void testSetup();
}
