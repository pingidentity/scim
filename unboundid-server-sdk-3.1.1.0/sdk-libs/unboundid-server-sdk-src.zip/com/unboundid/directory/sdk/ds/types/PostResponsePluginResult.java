/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.ds.types;



import java.io.Serializable;

import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class defines a structure which may be used to provide information about
 * the result of the processing performed by a post-response plugin.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class PostResponsePluginResult
       implements Serializable
{
  /**
   * A predefined result instance that indicates all processing completed
   * successfully.
   */
  public static final PostResponsePluginResult SUCCESS =
       new PostResponsePluginResult(false, true);



  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -255249379093850659L;



  // Indicates whether the client connection was terminated by the plugin.
  private final boolean connectionTerminated;

  // Indicates whether the server should continue processing other
  // post-response plugins.
  private final boolean continuePluginProcessing;



  /**
   * Creates a new post-response plugin result with the provided information.
   *
   * @param  connectionTerminated      Indicates whether the client connection
   *                                   was terminated by the plugin.
   * @param  continuePluginProcessing  Indicates whether to continue processing
   *                                   other post-response plugins for the
   *                                   operation.
   */
  public PostResponsePluginResult(final boolean connectionTerminated,
                                 final boolean continuePluginProcessing)
  {
    this.connectionTerminated     = connectionTerminated;
    this.continuePluginProcessing = continuePluginProcessing;
  }



  /**
   * Indicates whether the client connection was terminated by the plugin.
   *
   * @return  {@code true} if the client connection was terminated by the
   *          plugin, or {@code false} if not.
   */
  public boolean connectionTerminated()
  {
    return connectionTerminated;
  }



  /**
   * Indicates whether to continue processing other post-response plugins for
   * the operation.
   *
   * @return  {@code true} if the server should continue processing other
   *          post-operation plugins for the operation, or {@code false} if not.
   */
  public boolean continuePluginProcessing()
  {
    return continuePluginProcessing;
  }



  /**
   * Retrieves a string representation of this post-response plugin result.
   *
   * @return  A string representation of this post-response plugin result.
   */
  @Override()
  public String toString()
  {
    final StringBuilder buffer = new StringBuilder();

    buffer.append("PostResponsePluginResult(connectionTerminated=");
    buffer.append(connectionTerminated);
    buffer.append(", continuePluginProcessing=");
    buffer.append(continuePluginProcessing);
    buffer.append(')');

    return buffer.toString();
  }
}
