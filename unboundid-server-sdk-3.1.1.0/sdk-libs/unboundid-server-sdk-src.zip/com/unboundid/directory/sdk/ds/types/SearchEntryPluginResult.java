/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.ds.types;



import java.io.Serializable;

import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class defines a structure which may be used to provide information about
 * the result of the processing performed by a search entry plugin.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class SearchEntryPluginResult
       implements Serializable
{
  /**
   * A predefined result instance that indicates all processing completed
   * successfully.
   */
  public static final SearchEntryPluginResult SUCCESS =
       new SearchEntryPluginResult(false, true, true, true);



  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 6301478866012072554L;



  // Indicates whether the client connection was terminated by the plugin.
  private final boolean connectionTerminated;

  // Indicates whether the server should continue processing other search entry
  // plugins for the associated entry.
  private final boolean continuePluginProcessing;

  // Indicates whether the server should continue processing for the associated
  // search operation.
  private final boolean continueSearchProcessing;

  // Indicates whether the associated entry should be returned to the client.
  private final boolean sendEntry;



  /**
   * Creates a new search entry plugin result with the provided information.
   *
   * @param  connectionTerminated      Indicates whether the client connection
   *                                   was terminated by the plugin.
   * @param  continuePluginProcessing  Indicates whether to continue processing
   *                                   other search entry plugins for the
   *                                   entry.
   * @param  sendEntry                 Indicates whether to send the entry to
   *                                   the client.
   * @param  continueSearchProcessing  Indicates whether to continue processing
   *                                   the associated search operation.
   */
  public SearchEntryPluginResult(final boolean connectionTerminated,
                                 final boolean continuePluginProcessing,
                                 final boolean sendEntry,
                                 final boolean continueSearchProcessing)
  {
    this.connectionTerminated     = connectionTerminated;
    this.continuePluginProcessing = continuePluginProcessing;
    this.sendEntry                = sendEntry;
    this.continueSearchProcessing = continueSearchProcessing;
  }



  /**
   * Indicates whether the client connection was terminated by the plugin.
   *
   * @return  {@code true} if the client connection was terminated by the
   *          plugin, or {@code false} if not.
   */
  public boolean connectionTerminated()
  {
    return connectionTerminated;
  }



  /**
   * Indicates whether to continue processing other search entry plugins for
   * the associated entry.
   *
   * @return  {@code true} if the server should continue processing other
   *          search entry plugins for the associated entry, or {@code false} if
   *          not.
   */
  public boolean continuePluginProcessing()
  {
    return continuePluginProcessing;
  }



  /**
   * Indicates whether to continue processing for the associated search
   * operation.
   *
   * @return  {@code true} if the server should continue processing for the
   *          associated search operation, or {@code false} if not and the
   *          search done response should be sent to the client.
   */
  public boolean continueSearchProcessing()
  {
    return continueSearchProcessing;
  }



  /**
   * Indicates whether the associated entry should be returned to the client.
   *
   * @return  {@code true} if the entry should be returned to the client, or
   *          {@code false} if the server should exclude the entry from the
   *          set of search results.
   */
  public boolean sendEntry()
  {
    return sendEntry;
  }



  /**
   * Retrieves a string representation of this search entry plugin result.
   *
   * @return  A string representation of this search entry plugin result.
   */
  @Override()
  public String toString()
  {
    final StringBuilder buffer = new StringBuilder();

    buffer.append("SearchEntryPluginResult(connectionTerminated=");
    buffer.append(connectionTerminated);
    buffer.append(", continuePluginProcessing=");
    buffer.append(continuePluginProcessing);
    buffer.append(", sendEntry=");
    buffer.append(sendEntry);
    buffer.append(", continueSearchProcessing=");
    buffer.append(continueSearchProcessing);
    buffer.append(')');

    return buffer.toString();
  }
}
