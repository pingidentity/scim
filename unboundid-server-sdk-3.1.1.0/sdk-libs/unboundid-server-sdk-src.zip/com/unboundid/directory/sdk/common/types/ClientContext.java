/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.common.types;



import java.net.InetAddress;

import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.util.NotExtensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This interface defines a set of methods that may be used to obtain
 * information about a client connection that has been established to the
 * server.
 */
@NotExtensible()
@ThreadSafety(level=ThreadSafetyLevel.INTERFACE_NOT_THREADSAFE)
public interface ClientContext
{
  /**
   * Retrieves the identifier that has been assigned to the associated client
   * connection.
   *
   * @return  The identifier that has been assigned to the associated client
   *          connection.
   */
  long getConnectionID();



  /**
   * Indicates whether this represents an internal client connection.
   *
   * @return  {@code true} if this represents an internal client connection, or
   *          {@code false} if it is from an external client.
   */
  boolean isInternal();



  /**
   * Indicates whether the client is communicating with the server in a secure
   * manner.
   *
   * @return  {@code true} if the client is communicating with the server in a
   *          secure manner, or {@code false} if not.
   */
  boolean isSecure();



  /**
   * Retrieves the name of the protocol that the client is using to communicate
   * with the server.
   *
   * @return  The name of the protocol that the client is using to communicate
   *          with the server.
   */
  String getProtocol();



  /**
   * Retrieves the time that the connection was established.  The value returned
   * will be an offset in milliseconds since 12:00 a.m. on January 1, 1970.
   *
   * @return  The time that the connection was established.
   */
  long getConnectTime();



  /**
   * Retrieves an {@code InetAddress} representing the address of the client
   * system, if available.
   *
   * @return  An {@code InetAddress} representing the address of the client
   *          system, or {@code null} if that is not available or applicable for
   *          the associated client connection.
   */
  InetAddress getClientInetAddress();



  /**
   * Retrieves an {@code InetAddress} representing the address on the server to
   * which the client established the connection, if available.
   *
   * @return  The address on the server to which the client established the
   *          connection, or {@code null} if that is not available or
   *          applicable.
   */
  InetAddress getServerInetAddress();



  /**
   * Indicates whether the client has authenticated to the server.
   *
   * @return  {@code true} if the client has authenticated to the server, or
   *          {@code false} if not.
   */
  boolean isAuthenticated();



  /**
   * Retrieves information about the authentication state of the client
   * connection.
   *
   * @return  Information about the authentication state of the client
   *          connection.
   */
  AuthInfo getAuthInfo();



  /**
   * Attempts to send an unsolicited notification to the client with the
   * provided information.
   *
   * @param  oid         The OID for the unsolicited notification.  It must not
   *                     be {@code null}.
   * @param  resultCode  The result code to use for the unsolicited
   *                     notification.  It must not be {@code null}.
   * @param  message     A message to include in the unsolicited notification.
   *                     It may be {@code null} if no message is needed.
   */
  void sendUnsolicitedNotification(final String oid,
                                   final ResultCode resultCode,
                                   final String message);



  /**
   * Terminates the connection to the client and interrupts any operations that
   * may be in progress on that connection.
   *
   * @param  reason        A general reason that the connection was closed.
   * @param  notifyClient  Indicates whether to attempt to send a notice of
   *                       disconnection to the client.
   * @param  message       A message with information about the reason for the
   *                       disconnect.  It may be {@code null} if none is
   *                       available.  It is generally recommended that a
   *                       message be provided even if the client should not be
   *                       notified, since the message may be used in other
   *                       ways (e.g., in log messages).
   */
  void disconnect(final DisconnectReason reason, final boolean notifyClient,
                  final String message);



  /**
   * Retrieves information about the server with which the client connection is
   * associated.
   *
   * @return  Information about the server with which the client connection is
   *          associated.
   */
  ServerContext getServerContext();



  /**
   * Retrieves a string representation of the client connection.
   *
   * @return  A string representation of the client connection.
   */
  String toString();
}
