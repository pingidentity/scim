/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.common.types;



import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.unboundid.directory.sdk.ds.api.ChangeListener;
import com.unboundid.directory.sdk.common.api.DiskSpaceConsumer;
import com.unboundid.directory.sdk.common.api.ServerShutdownListener;
import com.unboundid.directory.sdk.common.api.ServerThread;
import com.unboundid.directory.sdk.common.schema.Schema;
import com.unboundid.directory.sdk.ds.types.RegisteredChangeListener;
import com.unboundid.ldap.sdk.ChangeType;
import com.unboundid.ldap.sdk.Filter;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.util.NotExtensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This interface may be used to obtain information about the server in
 * which an extension is running.
 */
@NotExtensible()
@ThreadSafety(level=ThreadSafetyLevel.INTERFACE_THREADSAFE)
public interface ServerContext
{
  /**
   * Retrieves the compact name of the server vendor.  The returned name will
   * not have any spaces.
   *
   * @return  The compact name of the server vendor.
   */
  String getShortVendorName();



  /**
   * Retrieves the full name of the server vendor.  The returned name may
   * contain spaces.
   *
   * @return  The full name of the server vendor.
   */
  String getFullVendorName();



  /**
   * Retrieves the compact name of the server.  The returned name will not have
   * any spaces.
   *
   * @return  The compact name of the server.
   */
  String getCompactProductName();



  /**
   * Retrieves the full name of the server.  The returned name may contain
   * spaces.
   *
   * @return  The full name of the server.
   */
  String getFullProductName();



  /**
   * Retrieves the major version number for the server.  The major version
   * number is the first number which appears in the full version string (e.g.,
   * for a version string of "1.2.3.4-beta5", the major version number is 1).
   *
   * @return  The major version number for the server.
   */
  int getMajorVersionNumber();



  /**
   * Retrieves the minor version number for the server.  The minor version
   * number is the second number which appears in the full version string (e.g.,
   * for a version string of "1.2.3.4-beta5", the minor version number is 2).
   *
   * @return  The minor version number for the server.
   */
  int getMinorVersionNumber();



  /**
   * Retrieves the point version number for the server.  The point version
   * number is the third number which appears in the full version string (e.g.,
   * for a version string of "1.2.3.4-beta5", the point version number is 3).
   *
   * @return  The point version number for the server.
   */
  int getPointVersionNumber();



  /**
   * Retrieves the patch version number for the server.  The patch version
   * number is the fourth number which appears in the full version string (e.g.,
   * for a version string of "1.2.3.4-beta5", the patch version number is 4).
   *
   * @return  The point version number for the server.
   */
  int getPatchVersionNumber();



  /**
   * Retrieves the version qualifier string for the server.  The version
   * qualifier is an optional string which may provide additional information
   * about the server version.  If a version qualifier is present, then it will
   * immediately follow the patch version number (e.g., for a version string of
   * "1.2.3.4-beta5", the version qualifier is "-beta5").
   *
   * @return  The version qualifier for the server, or an empty string if no
   *          version qualifier is defined.
   */
  String getVersionQualifier();



  /**
   * Retrieves a value which identifies the source revision (in the
   * version control system used to hold the server source code) from which the
   * server was built.
   *
   * @return  The source revision identifier for the server.
   */
  String getSourceRevision();



  /**
   * Indicates whether the server is in the process of starting up.
   *
   * @return  {@code true} if the server is in the process of starting up, or
   *          {@code false} if not.
   */
  boolean isStarting();



  /**
   * Indicates whether the server is currently running.
   *
   * @return  {@code true} if the server is running, or {@code false} if not.
   */
  boolean isRunning();



  /**
   * Indicates whether the server is in the process of shutting down.
   *
   * @return  {@code true} if the server is in the process of shutting down, or
   *          {@code false} if not.
   */
  boolean isShuttingDown();



  /**
   * Retrieves the time that the server was started.  The value returned will
   * be an offset in milliseconds since 12:00 a.m. on January 1, 1970.
   *
   * @return  The time that the server was started.
   */
  long getStartTime();



  /**
   * Retrieves a compact ID that was generated at the time the server was
   * started.  It is not guaranteed to be unique among all instances of the
   * server, but is guaranteed to be unique across all invocations of a single
   * server installation.  This is suitable for inclusion in log messages and
   * can help differentiate operations with the same connection ID and operation
   * ID across server restarts.
   *
   * @return  A compact ID that was generated at the time the server was
   *          started.
   */
  String getStartupID();



  /**
   * Retrieves a unique identifier that was generated at the time the server was
   * started.  It will be unique across all server instances and all invocations
   * of the same instance.
   *
   * @return  A unique identifier that was generated at the time the server was
   *          started.
   */
  UUID getStartupUUID();



  /**
   * Retrieves the instance name that has been assigned to the server.
   *
   * @return  The instance name that has been assigned to the server.
   */
  String getInstanceName();




  /**
   * Retrieves the path to the server root directory.
   *
   * @return  The path to the server root directory.
   */
  File getServerRoot();



  /**
   * Indicates whether the extension is running in a server that has Directory
   * Server functionality available.
   *
   * @return  {@code true} if Directory Server functionality is available, or
   *          {@code false} if not.
   */
  boolean isDirectoryFunctionalityAvailable();



  /**
   * Indicates whether the extension is running in a server that has Directory
   * Proxy Server functionality available.
   *
   * @return  {@code true} if Directory Proxy Server functionality is available,
   *          or {@code false} if not.
   */
  boolean isDirectoryProxyFunctionalityAvailable();



  /**
   * Indicates whether the extension is running in a server that has
   * Synchronization Server functionality available.
   *
   * @return  {@code true} if Synchronization Server functionality is available,
   *          or {@code false} if not.
   */
  boolean isSyncFunctionalityAvailable();



  /**
   * Retrieves an internal connection that is authenticated as a root user
   * that is not subject to access control.
   *
   * @return  An internal connection that is authenticated as a root user.
   */
  InternalConnection getInternalRootConnection();



  /**
   * Retrieves an internal connection that is authenticated as the specified
   * user.  Operations on the connection may be subject to access control based
   * on the privileges associated with the specified user.
   *
   * @param  dn  The DN of the user as whom the connection should be
   *             authenticated.  It may be {@code null} or empty if the
   *             connection should be unauthenticated.
   *
   * @return  An internal connection that is authenticated as the specified
   *          user.
   *
   * @throws  LDAPException  If a problem occurs while attempting to
   *                         authenticate as the specified user.
   */
  InternalConnection getInternalConnection(final String dn)
       throws LDAPException;



  /**
   * Retrieves a reference to the server schema.
   *
   * @return  A reference to the server schema.
   */
  Schema getSchema();



  /**
   * Registers the provided change listener with the server so that it may be
   * notified of any changes matching the provided criteria.
   *
   * @param  listener     The change listener to be registered with the server.
   *                      It must not be {@code null}.
   * @param  changeTypes  The types of changes for which the listener should be
   *                      registered.  It may be {@code null} or empty to
   *                      indicate that the listener should be registered for
   *                      all types of changes.
   * @param  baseDNs      The set of base DNs for which the listener should be
   *                      registered.  It may be {@code null} or empty to
   *                      indicate that the listener should be registered for
   *                      changes processed anywhere in the server.
   * @param  filter       A filter which may be used to restrict the set of
   *                      changes for which the listener is notified.  If a
   *                      filter is provided, then only changes in which the
   *                      target entry matches the given filter (either before
   *                      or after the change was processed) will be notified.
   *                      It may be {@code null} to indicate that the contents
   *                      of the entry should not be considered.
   *
   * @return  An object representing the change listener that has been
   *          registered with the server.
   *
   * @throws  LDAPException  If a problem is encountered while attempting to
   *                         register the provided change listener (e.g., if any
   *                         of the base DNs cannot be parsed as a valid DN).
   */
  RegisteredChangeListener registerChangeListener(final ChangeListener listener,
                                final Set<ChangeType> changeTypes,
                                final List<String> baseDNs,
                                final Filter filter)
       throws LDAPException;



  /**
   * Deregisters the provided change listener with the server.  This will have
   * no effect if the provided listener is not registered.
   *
   * @param  listener  The change listener to be deregistered.  It must not be
   *                   {@code null}.
   */
  void deregisterChangeListener(final RegisteredChangeListener listener);



  /**
   * Registers the provided disk space consumer with the server.
   *
   * @param  consumer  The disk space consumer to be registered with the server.
   *                   It must not be {@code null}.
   *
   * @return  An object representing the disk space consumer that has been
   *          registered with the server.
   */
  RegisteredDiskSpaceConsumer registerDiskSpaceConsumer(
                                   final DiskSpaceConsumer consumer);



  /**
   * Deregisters the provided disk space consumer with the server.  This will no
   * no effect if the provided consumer is not registered.
   *
   * @param  consumer  The disk space consumer to be deregistered with the
   *                   server. It must not be {@code null}.
   */
  void deregisterDiskSpaceConsumer(final RegisteredDiskSpaceConsumer consumer);



  /**
   * Registers the provided listener to be notified when the server shutdown
   * process has begun.
   *
   * @param  listener  The server shutdown listener to be registered.  It must
   *                   not be {@code null}.
   *
   * @return  An object representing the shutdown listener that has been
   *          registered with the server.
   */
  RegisteredServerShutdownListener registerShutdownListener(
                                        final ServerShutdownListener listener);



  /**
   * Deregisters the provided server shutdown listener with the server.  This
   * will have no effect if the provided listener is not registered.
   *
   * @param  listener  The server shutdown listener to be deregistered.  It must
   *                   not be {@code null}.
   */
  void deregisterShutdownListener(
            final RegisteredServerShutdownListener listener);



  /**
   * Creates a new thread to run within the server.  The thread will not be
   * started.
   *
   * @param  name          The name to use for the thread.  It must not be
   *                       {@code null} or empty.
   * @param  serverThread  The class providing the logic for the thread.  It
   *                       must not be {@code null}.
   *
   * @return  The thread that has been created but not yet started.
   */
  Thread createThread(final ServerThread serverThread, final String name);



  /**
   * Writes a message to the server error log.
   *
   * @param  severity  The severity to use for the log message.  It must not be
   *                   {@code null}.
   * @param  message   The message to be logged.  It must not be {@code null}.
   */
  void logMessage(final LogSeverity severity, final String message);



  /**
   * Generates an administrative alert notification.
   *
   * @param  severity  The severity to use for the alert notification.  It must
   *                   not be {@code null}.
   * @param  message   The message to be used for the alert notification.  It
   *                   must not be {@code null}.
   */
  void sendAlert(final AlertSeverity severity, final String message);



  /**
   * Generates an administrative alert notification.
   *
   * @param  alertTypeName  The name to use to identify the alert type.  Each
   *                        kind of alert must have a distinct name and all
   *                        alerts with this alert type must always be used with
   *                        the same severity and OID values.  Alert type names
   *                        must start with a lowercase ASCII letter and must
   *                        contain only lowercase ASCII letters, numeric
   *                        digits, and dashes.
   * @param  severity       The severity to use for the alert notification.
   *                        It must not be {@code null}.
   * @param  alertTypeOID   The numeric OID for the alert type.  It must not be
   *                        {@code null}, and it must be a valid numeric OID.
   *                        The same OID must always be used for the associated
   *                        alert type, and each different alert type must have
   *                        a unique OID.
   * @param  message        The message to be used for the alert notification.
   *                        It must not be {@code null}.
   *
   * @throws  LDAPException  If the provided information cannot be used to
   *                         generate a valid alert (e.g., if the alert type
   *                         name does not meet the naming constraints or has
   *                         already been used with a different severity and/or
   *                         OID, or if the OID has already been used with a
   *                         different alert type).
   */
  void sendAlert(final String alertTypeName, final AlertSeverity severity,
                 final String alertTypeOID, final String message)
       throws LDAPException;



  /**
   * Indicates whether debugging is enabled in the server.
   *
   * @return  {@code true} if debugging is enabled in the server, or
   *          {@code false} if not.
   */
  boolean debugEnabled();



  /**
   * Writes a debug message indicating that the provided exception has been
   * caught.
   *
   * @param  t  The exception that has been caught.
   */
  void debugCaught(final Throwable t);



  /**
   * Writes a debug message indicating that the provided exception will be
   * thrown.
   *
   * @param  t  The exception that will be thrown.
   */
  void debugThrown(final Throwable t);



  /**
   * Writes a debug message with an error severity.
   *
   * @param  message  The message to be debugged.
   */
  void debugError(final String message);



  /**
   * Writes a debug message with a warning severity.
   *
   * @param  message  The message to be debugged.
   */
  void debugWarning(final String message);



  /**
   * Writes a debug message with an informational severity.
   *
   * @param  message  The message to be debugged.
   */
  void debugInfo(final String message);



  /**
   * Writes a debug message with a verbose severity.
   *
   * @param  message  The message to be debugged.
   */
  void debugVerbose(final String message);
}
