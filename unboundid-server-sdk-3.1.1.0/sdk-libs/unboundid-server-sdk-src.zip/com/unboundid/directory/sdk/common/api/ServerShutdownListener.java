/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.common.api;



import com.unboundid.directory.sdk.ds.internal.DirectoryServerExtension;
import com.unboundid.directory.sdk.proxy.internal.DirectoryProxyServerExtension;
import com.unboundid.directory.sdk.sync.internal.SynchronizationServerExtension;
import com.unboundid.util.Extensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This interface defines a set of methods that should be implemented by classes
 * which should be notified when the server has begun the process of shutting
 * down.  Shutdown listeners should be registered with the server using the
 * {@code ServerContext.registerShutdownListener} method, and the corresponding
 * {@code deregisterShutdownListener} should be used to deregister the listener
 * if it is no longer needed.
 * <BR><BR>
 * Most types of extensions will not need to implement this interface, since
 * they may use their own finalization method to be notified when the extension
 * is to be taken out of service (either because the server is shutting down or
 * because the extension is being disabled or removed).  However, it may be
 * useful for background threads that may not be tied to any single instance of
 * an extension.
 */
@Extensible()
@DirectoryServerExtension()
@DirectoryProxyServerExtension(appliesToLocalContent=true,
     appliesToRemoteContent=false)
@SynchronizationServerExtension(appliesToLocalContent=true,
     appliesToSynchronizedContent=false)
@ThreadSafety(level=ThreadSafetyLevel.INTERFACE_NOT_THREADSAFE)
public interface ServerShutdownListener
{
  /**
   * Performs any processing that may be necessary when the server begins the
   * shutdown process.
   *
   * @param  reason  Information about the reason for the shutdown.
   */
  void processServerShutdown(final String reason);
}
