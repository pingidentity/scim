/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */



/**
 * This package contains sample programs that demonstrate the use of the
 * UnboundID LDAP SDK for Java, and in particular portions of the LDAP SDK which
 * are only available in the Commercial Edition.  See the
 * com.unboundid.ldap.sdk.examples package for a set of examples that use only
 * features found in the Standard Edition.
 * <BR<BR>
 * Note that the scope of these programs has been intentionally kept small so
 * that they are easier to understand, even though this may limit the real-world
 * usefulness of these examples.  Further, these programs do not include
 * support for internationalization and have minimal debugging code to further
 * simplify them.
 */
package com.unboundid.ldap.sdk.unboundidds.examples;
