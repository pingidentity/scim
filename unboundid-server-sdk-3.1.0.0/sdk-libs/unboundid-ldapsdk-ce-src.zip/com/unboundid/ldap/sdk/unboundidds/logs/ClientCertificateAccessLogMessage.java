/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about a client
 * certificate that has been presented to the server.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class ClientCertificateAccessLogMessage
       extends AccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -2585979292882352926L;



  // The subject DN for the issuer certificate.
  private final String issuerSubject;

  // The subject DN for the client certificate.
  private final String peerSubject;



  /**
   * Creates a new client certificate access log message from the provided
   * message string.
   *
   * @param  s  The string to be parsed as a client certificate access log
   *            message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public ClientCertificateAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new connect access log message from the provided log message.
   *
   * @param  m  The log message to be parsed as a connect access log message.
   */
  public ClientCertificateAccessLogMessage(final LogMessage m)
  {
    super(m);

    peerSubject   = getNamedValue("peerSubject");
    issuerSubject = getNamedValue("issuerSubject");
  }



  /**
   * Retrieves the subject of the peer certificate.
   *
   * @return  The subject of the peer certificate, or {@code null} if it is not
   *          included in the log message.
   */
  public String getPeerSubject()
  {
    return peerSubject;
  }



  /**
   * Retrieves the subject of the issuer certificate.
   *
   * @return  The subject of the issuer certificate, or {@code null} if it is
   *          not included in the log message.
   */
  public String getIssuerSubject()
  {
    return issuerSubject;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogMessageType getMessageType()
  {
    return AccessLogMessageType.CLIENT_CERTIFICATE;
  }
}
