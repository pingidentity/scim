/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about an unbind
 * request received from a client.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class UnbindRequestAccessLogMessage
       extends OperationRequestAccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 837856533259958468L;



  /**
   * Creates a new unbind request access log message from the provided message
   * string.
   *
   * @param  s  The string to be parsed as an unbind request access log
   *            message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public UnbindRequestAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new unbind request access log message from the provided log
   * message.
   *
   * @param  m  The log message to be parsed as an unbind request access log
   *            message.
   */
  public UnbindRequestAccessLogMessage(final LogMessage m)
  {
    super(m);
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogOperationType getOperationType()
  {
    return AccessLogOperationType.UNBIND;
  }
}
