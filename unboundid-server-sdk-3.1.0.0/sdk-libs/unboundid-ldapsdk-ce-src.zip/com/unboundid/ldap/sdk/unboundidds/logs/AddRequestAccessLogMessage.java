/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotExtensible;
import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about an add
 * request received from a client.
 */
@NotExtensible()
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public class AddRequestAccessLogMessage
       extends OperationRequestAccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -1234543653722421757L;



  // The DN of the entry to add.
  private final String dn;



  /**
   * Creates a new add request access log message from the provided message
   * string.
   *
   * @param  s  The string to be parsed as an add request access log message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public AddRequestAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new add request access log message from the provided message
   * string.
   *
   * @param  m  The log message to be parsed as an add request access log
   *            message.
   */
  public AddRequestAccessLogMessage(final LogMessage m)
  {
    super(m);

    dn = getNamedValue("dn");
  }



  /**
   * Retrieves the DN of the entry to add.
   *
   * @return  The DN of the entry to add, or {@code null} if it is not included
   *          in the log message.
   */
  public final String getDN()
  {
    return dn;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public final AccessLogOperationType getOperationType()
  {
    return AccessLogOperationType.ADD;
  }
}
