/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about a search
 * result entry returned to a client.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class SearchEntryAccessLogMessage
       extends OperationAccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 6423635071693560277L;



  // The list of response control OIDs for the operation.
  private final List<String> responseControlOIDs;

  // The DN of the entry returned.
  private final String dn;



  /**
   * Creates a new search result entry access log message from the provided
   * message string.
   *
   * @param  s  The string to be parsed as a search result entry access log
   *            message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public SearchEntryAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new search result entry access log message from the provided log
   * message.
   *
   * @param  m  The log message to be parsed as a search entry access log
   *            message.
   */
  public SearchEntryAccessLogMessage(final LogMessage m)
  {
    super(m);

    dn = getNamedValue("dn");

    final String controlStr = getNamedValue("responseControls");
    if (controlStr == null)
    {
      responseControlOIDs = Collections.emptyList();
    }
    else
    {
      final LinkedList<String> controlList = new LinkedList<String>();
      final StringTokenizer t = new StringTokenizer(controlStr, ",");
      while (t.hasMoreTokens())
      {
        controlList.add(t.nextToken());
      }
      responseControlOIDs = Collections.unmodifiableList(controlList);
    }
  }



  /**
   * Retrieves the DN of the entry returned to the client.
   *
   * @return  The DN of the entry returned to the client, or {@code null} if it
   *          is not included in the log message.
   */
  public String getDN()
  {
    return dn;
  }



  /**
   * Retrieves the OIDs of any response controls contained in the log message.
   *
   * @return  The OIDs of any response controls contained in the log message, or
   *          an empty list if it is not included in the log message.
   */
  public List<String> getResponseControlOIDs()
  {
    return responseControlOIDs;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogMessageType getMessageType()
  {
    return AccessLogMessageType.ENTRY;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogOperationType getOperationType()
  {
    return AccessLogOperationType.SEARCH;
  }
}
