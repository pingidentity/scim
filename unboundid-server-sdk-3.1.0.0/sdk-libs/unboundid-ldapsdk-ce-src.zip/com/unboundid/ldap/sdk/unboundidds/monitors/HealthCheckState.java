/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.monitors;



import com.unboundid.util.StaticUtils;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides information about the health check states that may be
 * held by an LDAP external server.
 */
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public enum HealthCheckState
{
  /**
   * The health check state that indicates that the associated LDAP external
   * server is available.
   */
  AVAILABLE("available"),



  /**
   * The health check state that indicates that the associated LDAP external
   * server is in a degraded state.
   */
  DEGRADED("degraded"),



  /**
   * The health check state that indicates that the associated LDAP external
   * server is unavailable.
   */
  UNAVAILABLE("unavailable");



  // The name for this health check state.
  private final String name;



  /**
   * Creates a new health check state with the specified name.
   *
   * @param  name  The name for this health check state.
   */
  private HealthCheckState(final String name)
  {
    this.name = name;
  }



  /**
   * Retrieves the name for this health check state.
   *
   * @return  The name for this health check state.
   */
  public String getName()
  {
    return name;
  }



  /**
   * Retrieves the health check state with the specified name.
   *
   * @param  name  The name of the health check state to retrieve.
   *
   * @return  The health check state with the specified name, or {@code null} if
   *          there is no health check state with the given name.
   */
  public static HealthCheckState forName(final String name)
  {
    final String lowerName = StaticUtils.toLowerCase(name);

    if (lowerName.equals("available"))
    {
      return AVAILABLE;
    }
    else if (lowerName.equals("degraded"))
    {
      return DEGRADED;
    }
    else if (lowerName.equals("unavailable"))
    {
      return UNAVAILABLE;
    }
    else
    {
      return null;
    }
  }



  /**
   * Retrieves a string representation of this health check state.
   *
   * @return  A string representation of this health check state.
   */
  @Override()
  public String toString()
  {
    return name;
  }
}
