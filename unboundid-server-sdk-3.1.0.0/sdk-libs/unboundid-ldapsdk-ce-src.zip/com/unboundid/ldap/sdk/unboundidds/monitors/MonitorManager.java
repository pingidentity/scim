/*
 * Copyright 2008-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.monitors;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

import com.unboundid.ldap.sdk.Filter;
import com.unboundid.ldap.sdk.LDAPConnection;
import com.unboundid.ldap.sdk.LDAPSearchException;
import com.unboundid.ldap.sdk.SearchResult;
import com.unboundid.ldap.sdk.SearchResultEntry;
import com.unboundid.ldap.sdk.SearchScope;
import com.unboundid.util.DebugType;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;

import static com.unboundid.util.Debug.*;



/**
 * This class provides a set of methods for retrieving Directory Server monitor
 * entries.  In particular, it provides methods for retrieving all monitor
 * entries from the server, as well as retrieving monitor entries of specific
 * types.
 * <BR><BR>
 * <H2>Example</H2>
 * The following example demonstrates the process for retrieving all monitor
 * entries published by the directory server and printing the information
 * contained in each using the generic API for accessing monitor entry data:
 * <PRE>
 *   for (MonitorEntry e : MonitorManager.getMonitorEntries(connection))
 *   {
 *     System.out.println("Monitor Name:  " + e.getMonitorName());
 *     System.out.println("Monitor Type:  " + e.getMonitorDisplayName());
 *     System.out.println("Monitor Data:");
 *     for (MonitorAttribute a : e.getMonitorAttributes().values())
 *     {
 *       for (Object value : a.getValues())
 *       {
 *         System.out.println("  " + a.getDisplayName() + ":  " +
 *                            String.valueOf(value));
 *       }
 *     }
 *     System.out.println();
 *   }
 * </PRE>
 */
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class MonitorManager
{
  /**
   * Prevent this class from being instantiated.
   */
  private MonitorManager()
  {
    // No implementation is required.
  }



  /**
   * Retrieves a list of all monitor entries available in the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all monitor entries available in the Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<MonitorEntry> getMonitorEntries(
                                        final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         MonitorEntry.GENERIC_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<MonitorEntry> monitorEntries =
         new ArrayList<MonitorEntry>(searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(MonitorEntry.decode(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the general monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The general monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static GeneralMonitorEntry getGeneralMonitorEntry(
                                         final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createPresenceFilter("objectClass");

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.BASE,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getGeneralMonitorEntry");

      return null;
    }

    return new GeneralMonitorEntry(searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the active operations monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The active operations monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static ActiveOperationsMonitorEntry
                     getActiveOperationsMonitorEntry(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ActiveOperationsMonitorEntry.ACTIVE_OPERATIONS_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getActiveOperationsMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getActiveOperationsMonitorEntry");
    }

    return new ActiveOperationsMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves a list of all backend monitor entries available in the Directory
   * Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all backend monitor entries available in the Directory
   *          Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<BackendMonitorEntry> getBackendMonitorEntries(
                                               final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         BackendMonitorEntry.BACKEND_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<BackendMonitorEntry> monitorEntries =
         new ArrayList<BackendMonitorEntry>(searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new BackendMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the client connection monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The client connection monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static ClientConnectionMonitorEntry
                     getClientConnectionMonitorEntry(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ClientConnectionMonitorEntry.CLIENT_CONNECTION_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getClientConnectionMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getClientConnectionMonitorEntry");
    }

    return new ClientConnectionMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves a list of all connection handler monitor entries available in the
   * Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all connection handler monitor entries available in the
   *          Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<ConnectionHandlerMonitorEntry>
                     getConnectionHandlerMonitorEntries(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ConnectionHandlerMonitorEntry.CONNECTION_HANDLER_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<ConnectionHandlerMonitorEntry> monitorEntries =
         new ArrayList<ConnectionHandlerMonitorEntry>(
                  searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new ConnectionHandlerMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the disk space usage monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The disk space usage monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static DiskSpaceUsageMonitorEntry getDiskSpaceUsageMonitorEntry(
                                                final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         DiskSpaceUsageMonitorEntry.DISK_SPACE_USAGE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getDiskSpaceUsageMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getDiskSpaceUsageMonitorEntry");
    }

    return new DiskSpaceUsageMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the entry cache monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The entry cache monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static EntryCacheMonitorEntry getEntryCacheMonitorEntry(
                                            final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         EntryCacheMonitorEntry.ENTRY_CACHE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getEntryCacheMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getEntryCacheMonitorEntry");
    }

    return new EntryCacheMonitorEntry(searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves a list of all index monitor entries available in the Directory
   * Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all index monitor entries available in the Directory
   *          Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<IndexMonitorEntry> getIndexMonitorEntries(
                                             final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         IndexMonitorEntry.INDEX_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<IndexMonitorEntry> monitorEntries =
         new ArrayList<IndexMonitorEntry>(searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new IndexMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves a list of all JE environment monitor entries available in the
   * Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all JE environment monitor entries available in the
   *          Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<JEEnvironmentMonitorEntry>
                     getJEEnvironmentMonitorEntries(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         JEEnvironmentMonitorEntry.JE_ENVIRONMENT_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<JEEnvironmentMonitorEntry> monitorEntries =
         new ArrayList<JEEnvironmentMonitorEntry>(searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new JEEnvironmentMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves a list of all LDAP external server monitor entries available in
   * the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all LDAP external server monitor entries available in
   *          the Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<LDAPExternalServerMonitorEntry>
                     getLDAPExternalServerMonitorEntries(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         LDAPExternalServerMonitorEntry.LDAP_EXTERNAL_SERVER_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<LDAPExternalServerMonitorEntry> monitorEntries =
         new ArrayList<LDAPExternalServerMonitorEntry>(
                  searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new LDAPExternalServerMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves a list of all LDAP statistics monitor entries available in the
   * Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all LDAP statistics monitor entries available in the
   *          Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<LDAPStatisticsMonitorEntry>
                     getLDAPStatisticsMonitorEntries(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         LDAPStatisticsMonitorEntry.LDAP_STATISTICS_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<LDAPStatisticsMonitorEntry> monitorEntries =
         new ArrayList<LDAPStatisticsMonitorEntry>(
                  searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new LDAPStatisticsMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the memory usage monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The memory usage monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static MemoryUsageMonitorEntry getMemoryUsageMonitorEntry(
                                             final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         MemoryUsageMonitorEntry.MEMORY_USAGE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getMemoryUsageMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getMemoryUsageMonitorEntry");
    }

    return new MemoryUsageMonitorEntry(searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the processing time histogram monitor entry from the Directory
   * Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The processing time histogram monitor entry from the Directory
   *          Server, or {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static ProcessingTimeHistogramMonitorEntry
                     getProcessingTimeHistogramMonitorEntry(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         ProcessingTimeHistogramMonitorEntry.
                              PROCESSING_TIME_HISTOGRAM_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getProcessingTimeHistogramMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in " +
            "getProcessingTimeHistogramMonitorEntry");
    }

    return new ProcessingTimeHistogramMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves a list of all replica monitor entries available in the Directory
   * Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all replica monitor entries available in the Directory
   *          Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<ReplicaMonitorEntry> getReplicaMonitorEntries(
                                               final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ReplicaMonitorEntry.REPLICA_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<ReplicaMonitorEntry> monitorEntries =
         new ArrayList<ReplicaMonitorEntry>(
                  searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new ReplicaMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the replication server monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The replication server monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static ReplicationServerMonitorEntry getReplicationServerMonitorEntry(
                     final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ReplicationServerMonitorEntry.REPLICATION_SERVER_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getReplicationServerMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in " +
            "getReplicationServerMonitorEntry");
    }

    return new ReplicationServerMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves a list of all replication summary monitor entries available in
   * the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  A list of all replication summary monitor entries available in the
   *          Directory Server.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static List<ReplicationSummaryMonitorEntry>
                     getReplicationSummaryMonitorEntries(
                          final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         ReplicationSummaryMonitorEntry.REPLICATION_SUMMARY_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final ArrayList<ReplicationSummaryMonitorEntry> monitorEntries =
         new ArrayList<ReplicationSummaryMonitorEntry>(
                  searchResult.getEntryCount());
    for (final SearchResultEntry e : searchResult.getSearchEntries())
    {
      monitorEntries.add(new ReplicationSummaryMonitorEntry(e));
    }

    return Collections.unmodifiableList(monitorEntries);
  }



  /**
   * Retrieves the system info monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The system info monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static SystemInfoMonitorEntry getSystemInfoMonitorEntry(
                                            final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         SystemInfoMonitorEntry.SYSTEM_INFO_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getSystemInfoMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getSystemInfoMonitorEntry");
    }

    return new SystemInfoMonitorEntry(searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the stack trace monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The stack trace monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static StackTraceMonitorEntry getStackTraceMonitorEntry(
                                            final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
                         StackTraceMonitorEntry.STACK_TRACE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getStackTraceMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getStackTraceMonitorEntry");
    }

    return new StackTraceMonitorEntry(searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the traditional work queue monitor entry from the Directory
   * Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The traditional work queue monitor entry from the Directory
   *          Server, or {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static TraditionalWorkQueueMonitorEntry
         getTraditionalWorkQueueMonitorEntry(final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         TraditionalWorkQueueMonitorEntry.TRADITIONAL_WORK_QUEUE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getTraditionalWorkQueueMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getTraditionalWorkQueueMonitorEntry");
    }

    return new TraditionalWorkQueueMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the UnboundID work queue monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The UnboundID work queue monitor entry from the Directory Server,
   *          or {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static UnboundIDWorkQueueMonitorEntry
         getUnboundIDWorkQueueMonitorEntry(final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         UnboundIDWorkQueueMonitorEntry.UNBOUNDID_WORK_QUEUE_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getUnboundIDWorkQueueMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getUnboundIDWorkQueueMonitorEntry");
    }

    return new UnboundIDWorkQueueMonitorEntry(
                    searchResult.getSearchEntries().get(0));
  }



  /**
   * Retrieves the version monitor entry from the Directory Server.
   *
   * @param  connection  The connection to use to communicate with the Directory
   *                     Server.
   *
   * @return  The version monitor entry from the Directory Server, or
   *          {@code null} if it is not available.
   *
   * @throws  LDAPSearchException  If a problem occurs while communicating with
   *                               the Directory Server.
   */
  public static VersionMonitorEntry getVersionMonitorEntry(
                                         final LDAPConnection connection)
         throws LDAPSearchException
  {
    final Filter filter = Filter.createEqualityFilter("objectClass",
         VersionMonitorEntry.VERSION_MONITOR_OC);

    final SearchResult searchResult =
         connection.search(MonitorEntry.MONITOR_BASE_DN, SearchScope.SUB,
                           filter);

    final int numEntries = searchResult.getEntryCount();
    if (numEntries == 0)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "No entries returned in getVersionMonitorEntry");

      return null;
    }
    else if (numEntries != 1)
    {
      debug(Level.FINE, DebugType.MONITOR,
            "Multiple entries returned in getVersionMonitorEntry");
    }

    return new VersionMonitorEntry(searchResult.getSearchEntries().get(0));
  }
}
