/*
 * Copyright 2010-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.examples;



import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.unboundid.asn1.ASN1OctetString;
import com.unboundid.ldap.sdk.ExtendedResult;
import com.unboundid.ldap.sdk.LDAPConnection;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.IntermediateResponse;
import com.unboundid.ldap.sdk.IntermediateResponseListener;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.ldap.sdk.SearchScope;
import com.unboundid.ldap.sdk.unboundidds.extensions.
            StreamDirectoryValuesExtendedRequest;
import com.unboundid.ldap.sdk.unboundidds.extensions.
            StreamDirectoryValuesIntermediateResponse;
import com.unboundid.util.LDAPCommandLineTool;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;
import com.unboundid.util.args.ArgumentException;
import com.unboundid.util.args.ArgumentParser;
import com.unboundid.util.args.DNArgument;
import com.unboundid.util.args.FileArgument;



/**
 * This class provides a utility that uses the stream directory values extended
 * operation in order to obtain a listing of all entry DNs below a specified
 * base DN in the Directory Server.
 * <BR><BR>
 * The APIs demonstrated by this example include:
 * <UL>
 *   <LI>The use of the stream directory values extended operation.</LI>
 *   <LI>Intermediate response processing.</LI>
 *   <LI>The LDAP command-line tool API.</LI>
 *   <LI>Argument parsing.</LI>
 * </UL>
 */
@ThreadSafety(level=ThreadSafetyLevel.NOT_THREADSAFE)
public final class DumpDNs
       extends LDAPCommandLineTool
       implements IntermediateResponseListener
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 774432759537092866L;



  // The argument used to obtain the base DN.
  private DNArgument baseDN;

  // The argument used to obtain the output file.
  private FileArgument outputFile;

  // The number of DNs dumped.
  private final AtomicLong dnsWritten;

  // The print stream that will be used to output the DNs.
  private PrintStream outputStream;



  /**
   * Parse the provided command line arguments and perform the appropriate
   * processing.
   *
   * @param  args  The command line arguments provided to this program.
   */
  public static void main(final String[] args)
  {
    final ResultCode resultCode = main(args, System.out, System.err);
    if (resultCode != ResultCode.SUCCESS)
    {
      System.exit(resultCode.intValue());
    }
  }



  /**
   * Parse the provided command line arguments and perform the appropriate
   * processing.
   *
   * @param  args       The command line arguments provided to this program.
   * @param  outStream  The output stream to which standard out should be
   *                    written.  It may be {@code null} if output should be
   *                    suppressed.
   * @param  errStream  The output stream to which standard error should be
   *                    written.  It may be {@code null} if error messages
   *                    should be suppressed.
   *
   * @return  A result code indicating whether the processing was successful.
   */
  public static ResultCode main(final String[] args,
                                final OutputStream outStream,
                                final OutputStream errStream)
  {
    final DumpDNs tool = new DumpDNs(outStream, errStream);
    return tool.runTool(args);
  }



  /**
   * Creates a new instance of this tool.
   *
   * @param  outStream  The output stream to which standard out should be
   *                    written.  It may be {@code null} if output should be
   *                    suppressed.
   * @param  errStream  The output stream to which standard error should be
   *                    written.  It may be {@code null} if error messages
   *                    should be suppressed.
   */
  public DumpDNs(final OutputStream outStream, final OutputStream errStream)
  {
    super(outStream, errStream);

    baseDN       = null;
    outputFile   = null;
    outputStream = null;
    dnsWritten   = new AtomicLong(0L);
  }




  /**
   * Retrieves the name of this tool.  It should be the name of the command used
   * to invoke this tool.
   *
   * @return  The name for this tool.
   */
  @Override()
  public String getToolName()
  {
    return "dump-dns";
  }



  /**
   * Retrieves a human-readable description for this tool.
   *
   * @return  A human-readable description for this tool.
   */
  @Override()
  public String getToolDescription()
  {
    return "Obtain a listing of all of the DNs for all entries below a " +
         "specified base DN in the Directory Server.";
  }



  /**
   * Adds the arguments needed by this command-line tool to the provided
   * argument parser which are not related to connecting or authenticating to
   * the directory server.
   *
   * @param  parser  The argument parser to which the arguments should be added.
   *
   * @throws  ArgumentException  If a problem occurs while adding the arguments.
   */
  @Override()
  public void addNonLDAPArguments(final ArgumentParser parser)
         throws ArgumentException
  {
    baseDN = new DNArgument('b', "baseDN", true, 1, "{dn}",
         "The base DN below which to dump the DNs of all entries in the " +
              "Directory Server.");
    parser.addArgument(baseDN);

    outputFile = new FileArgument('f', "outputFile", false, 1, "{path}",
         "The path of the output file to which the entry DNs will be " +
              "written.  If this is not provided, then entry DNs will be " +
              "written to standard output.", false, true, true, false);
    parser.addArgument(outputFile);
  }



  /**
   * Performs the core set of processing for this tool.
   *
   * @return  A result code that indicates whether the processing completed
   *          successfully.
   */
  @Override()
  public ResultCode doToolProcessing()
  {
    // Create the writer that will be used to write the DNs.
    final File f = outputFile.getValue();
    if (f == null)
    {
      outputStream = getOut();
    }
    else
    {
      try
      {
        outputStream =
             new PrintStream(new BufferedOutputStream(new FileOutputStream(f)));
      }
      catch (final IOException ioe)
      {
        err("Unable to open output file '", f.getAbsolutePath(),
             " for writing:  ", String.valueOf(ioe));
        return ResultCode.LOCAL_ERROR;
      }
    }


    // Obtain a connection to the Directory Server.
    final LDAPConnection conn;
    try
    {
      conn = getConnection();
    }
    catch (final LDAPException le)
    {
      err("Unable to obtain a connection to the Directory Server:  ",
          le.getExceptionMessage());
      return le.getResultCode();
    }


    // Create the extended request.  Register this class as an intermediate
    // response listener, and indicate that we don't want any response time
    // limit.
    final StreamDirectoryValuesExtendedRequest streamValuesRequest =
         new StreamDirectoryValuesExtendedRequest(baseDN.getStringValue(),
              SearchScope.SUB, false, null, 1000);
    streamValuesRequest.setIntermediateResponseListener(this);
    streamValuesRequest.setResponseTimeoutMillis(0L);


    // Send the extended request to the server and get the result.
    try
    {
      final ExtendedResult streamValuesResult =
           conn.processExtendedOperation(streamValuesRequest);
      err("Processing completed.  ", dnsWritten.get(), " DNs written.");
      return streamValuesResult.getResultCode();
    }
    catch (final LDAPException le)
    {
      err("Unable  to send the stream directory values extended request to " +
          "the Directory Server:  ", le.getExceptionMessage());
      return le.getResultCode();
    }
    finally
    {
      if (f != null)
      {
        outputStream.close();
      }

      conn.close();
    }
  }



  /**
   * Retrieves a set of information that may be used to generate example usage
   * information.  Each element in the returned map should consist of a map
   * between an example set of arguments and a string that describes the
   * behavior of the tool when invoked with that set of arguments.
   *
   * @return  A set of information that may be used to generate example usage
   *          information.  It may be {@code null} or empty if no example usage
   *          information is available.
   */
  @Override()
  public LinkedHashMap<String[],String> getExampleUsages()
  {
    final LinkedHashMap<String[],String> exampleMap =
         new LinkedHashMap<String[],String>(1);

    final String[] args =
    {
      "--hostname", "server.example.com",
      "--port", "389",
      "--bindDN", "uid=admin,dc=example,dc=com",
      "--bindPassword", "password",
      "--baseDN", "dc=example,dc=com",
      "--outputFile", "example-dns.txt",
    };
    exampleMap.put(args,
         "Dump all entry DNs at or below 'dc=example,dc=com' to the file " +
              "'example-dns.txt'");

    return exampleMap;
  }



  /**
   * Indicates that the provided intermediate response has been returned by the
   * server and may be processed by this intermediate response listener.  In
   * this case, it will
   *
   * @param  intermediateResponse  The intermediate response that has been
   *                               returned by the server.
   */
  public void intermediateResponseReturned(
                   final IntermediateResponse intermediateResponse)
  {
    // Try to parse the intermediate response as a stream directory values
    // intermediate response.
    final StreamDirectoryValuesIntermediateResponse streamValuesIR;
    try
    {
      streamValuesIR =
           new StreamDirectoryValuesIntermediateResponse(intermediateResponse);
    }
    catch (final LDAPException le)
    {
      err("Unable to parse an intermediate response message as a stream " +
          "directory values intermediate response:  ",
          le.getExceptionMessage());
      return;
    }

    final String diagnosticMessage = streamValuesIR.getDiagnosticMessage();
    if ((diagnosticMessage != null) && (diagnosticMessage.length() > 0))
    {
      err(diagnosticMessage);
    }


    final List<ASN1OctetString> values = streamValuesIR.getValues();
    if ((values != null) && (! values.isEmpty()))
    {
      for (final ASN1OctetString s : values)
      {
        outputStream.println(s.toString());
      }

      final long updatedCount = dnsWritten.addAndGet(values.size());
      if (outputFile.isPresent())
      {
        err(updatedCount, " DNs written.");
      }
    }
  }
}
