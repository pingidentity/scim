/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotExtensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log.
 */
@NotExtensible()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public abstract class AccessLogMessage
       extends LogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 111497572975341652L;



  // The connection ID for this access log message.
  private final Long connectionID;

  // The Directory Server instance name for this access log message.
  private final String instanceName;

  // The server product name for this access log message.
  private final String productName;

  // The startup ID for this access log message;
  private final String startupID;



  /**
   * Creates a new access log message from the provided log message.
   *
   * @param  m  The log message to be parsed as an access log message.
   */
  protected AccessLogMessage(final LogMessage m)
  {
    super(m);

    productName  = getNamedValue("product");
    instanceName = getNamedValue("instanceName");
    startupID    = getNamedValue("startupID");
    connectionID = getNamedValueAsLong("conn");
  }



  /**
   * Retrieves the server product name for this access log message.
   *
   * @return  The server product name for this access log message, or
   *          {@code null} if it is not included in the log message.
   */
  public final String getProductName()
  {
    return productName;
  }



  /**
   * Retrieves the Directory Server instance name for this access log message.
   *
   * @return  The Directory Server instance name for this access log message, or
   *          {@code null} if it is not included in the log message.
   */
  public final String getInstanceName()
  {
    return instanceName;
  }



  /**
   * Retrieves the Directory Server startup ID for this access log message.
   *
   * @return  The Directory Server startup ID for this access log message, or
   *          {@code null} if it is not included in the log message.
   */
  public final String getStartupID()
  {
    return startupID;
  }



  /**
   * Retrieves the connection ID for the connection with which this access log
   * message is associated.
   *
   * @return  The connection ID for the connection with which this access log
   *          message is associated, or {@code null} if it is not included in
   *          the log message.
   */
  public final Long getConnectionID()
  {
    return connectionID;
  }



  /**
   * Retrieves the message type for this access log message.
   *
   * @return  The message type for this access log message.
   */
  public abstract AccessLogMessageType getMessageType();
}
