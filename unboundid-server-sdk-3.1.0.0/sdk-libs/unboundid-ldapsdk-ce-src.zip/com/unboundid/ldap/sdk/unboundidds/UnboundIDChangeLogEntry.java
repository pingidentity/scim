/*
 * Copyright 2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.unboundid.ldap.sdk.Attribute;
import com.unboundid.ldap.sdk.ChangeLogEntry;
import com.unboundid.ldap.sdk.ChangeType;
import com.unboundid.ldap.sdk.Entry;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.Modification;
import com.unboundid.ldap.sdk.ModificationType;
import com.unboundid.ldap.sdk.ReadOnlyEntry;
import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;

import static com.unboundid.ldap.sdk.unboundidds.UnboundIDDSMessages.*;



/**
 * This class provides an implementation of a changelog entry which provides
 * support for all standard changelog entry attributes as well as those unique
 * to the UnboundID Directory Server.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class UnboundIDChangeLogEntry
       extends ChangeLogEntry
{
  /**
   * The name of the attribute used to hold the previous values for all
   * attributes affected by the change.
   */
  public static final String ATTR_BEFORE_VALUES = "ds-changelog-before-values";



  /**
   * The name of the attribute used to hold the resulting values for all
   * attributes affected by the change.
   */
  public static final String ATTR_AFTER_VALUES = "ds-changelog-after-values";



  /**
   * The name of the attribute used to hold the values of key attributes from
   * the entry after the change was applied.
   */
  public static final String ATTR_KEY_VALUES =
       "ds-changelog-entry-key-attr-values";



  /**
   * The name of the attribute used to hold information about updated attributes
   * which had more values (whether before the change, after the change, or
   * both) than allowed to be shown in the before/after values attributes.
   */
  public static final String ATTR_EXCEEDED_MAX_VALUES =
       "ds-changelog-attr-exceeded-max-values-count";


  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 5861660390955523019L;



  // The values of key attributes as they appeared in the entry after the change
  // was applied (or before the delete if the entry was removed).
  private final List<Attribute> keyEntryAttributes;

  // The updated attributes as they appeared in the entry after the change was
  // applied.
  private final List<Attribute> updatedAttributesAfterChange;

  // The updated attributes as they appeared in the entry before the change was
  // applied.
  private final List<Attribute> updatedAttributesBeforeChange;

  // Information about updated attributes that had more values than are allowed
  // to be included in the ds-changelog-before-values or
  // ds-changelog-after-values attributes.
  private final List<ChangeLogEntryAttributeExceededMaxValuesCount>
       attributesThatExceededMaxValuesCount;



  /**
   * Creates a new UnboundID changelog entry object from the provided entry.
   *
   * @param  entry  The entry from which to create this changelog entry.
   *
   * @throws  LDAPException  If the provided entry cannot be parsed as a
   *                         changelog entry.
   */
  public UnboundIDChangeLogEntry(final Entry entry)
         throws LDAPException
  {
    super(entry);

    final String targetDN = entry.getAttributeValue(ATTR_TARGET_DN);

    if (entry.hasAttribute(ATTR_BEFORE_VALUES))
    {
      updatedAttributesBeforeChange = parseAddAttributeList(entry,
           ATTR_BEFORE_VALUES, targetDN);
    }
    else
    {
      updatedAttributesBeforeChange = Collections.emptyList();
    }

    if (entry.hasAttribute(ATTR_AFTER_VALUES))
    {
      updatedAttributesAfterChange = parseAddAttributeList(entry,
           ATTR_AFTER_VALUES, targetDN);
    }
    else
    {
      updatedAttributesAfterChange = Collections.emptyList();
    }

    if (entry.hasAttribute(ATTR_KEY_VALUES))
    {
      keyEntryAttributes =
           parseAddAttributeList(entry, ATTR_KEY_VALUES, targetDN);
    }
    else
    {
      keyEntryAttributes = Collections.emptyList();
    }

    final Attribute exceededMaxValues =
         entry.getAttribute(ATTR_EXCEEDED_MAX_VALUES);
    if (exceededMaxValues == null)
    {
      attributesThatExceededMaxValuesCount = Collections.emptyList();
    }
    else
    {
      final String[] values = exceededMaxValues.getValues();
      final ArrayList<ChangeLogEntryAttributeExceededMaxValuesCount> l =
           new ArrayList<ChangeLogEntryAttributeExceededMaxValuesCount>(
                values.length);
      for (final String value : values)
      {
        l.add(new ChangeLogEntryAttributeExceededMaxValuesCount(value));
      }
      attributesThatExceededMaxValuesCount = Collections.unmodifiableList(l);
    }
  }



  /**
   * Retrieves a list containing the set of attributes that were updated in the
   * associated modify or modify DN operation as they appeared before the change
   * was processed.
   *
   * @return  A list containing the set of updated attributes as they appeared
   *          in the entry before the associated modify or modify DN was
   *          processed, or an empty list if the change was not a modify or
   *          modify DN operation, none of the updated attributes previously
   *          existed in the target entry, the previous versions of the updated
   *          attributes had too many values to include, or the server is not
   *          configured to provide (or does not support providing) previous
   *          versions of updated attributes.
   */
  public List<Attribute> getUpdatedAttributesBeforeChange()
  {
    return updatedAttributesBeforeChange;
  }



  /**
   * Retrieves a list containing the set of attributes that were updated in the
   * associated modify or modify DN operation as they appeared after the change
   * was processed.
   *
   * @return  A list containing the set of updated attributes as they appeared
   *          in the entry after the associated modify or modify DN was
   *          processed, or an empty list if the change was not a modify or
   *          modify DN operation, none of the updated attributes existed in the
   *          entry after the change was processed, the resulting versions of
   *          the updated attributes had too many values to include, or the
   *          server is not configured to provide (or does not support
   *          providing) resulting versions of updated attributes.
   */
  public List<Attribute> getUpdatedAttributesAfterChange()
  {
    return updatedAttributesAfterChange;
  }



  /**
   * Retrieves information about any attributes updated in the associated modify
   * or modify DN operation that had too many values to include in the changelog
   * entry's set of before and/or after values.
   *
   * @return  Information about attributes updated in the associated modify or
   *          modify DN operation that had too many values to include in the
   *          changelog entry's set of before and/or after values, or an empty
   *          list if none of the updated attributes had too many values, the
   *          server is not configured to provide (or does not support
   *          providing) previous and resulting versions of updated attributes,
   *          or the change was not the result of a modify or modify DN
   *          operation.
   */
  public List<ChangeLogEntryAttributeExceededMaxValuesCount>
              getAttributesThatExceededMaxValuesCount()
  {
    return attributesThatExceededMaxValuesCount;
  }



  /**
   * Retrieves a list containing key attributes from the target entry, as
   * defined in the server configuration.  For add, modify, and modify DN
   * operations, this will include the key attributes as they appeared in the
   * entry after the change had been processed.  For delete operations, this
   * will include the key attributes as they appeared in the entry just before
   * it was removed.
   *
   * @return  A list containing key attributes from the target entry, or an
   *          empty list if the associated entry did not have any key attributes
   *          or there are no key attribute types defined in the server
   *          configuration.
   */
  public List<Attribute> getKeyEntryAttributes()
  {
    return keyEntryAttributes;
  }



  /**
   * Retrieves the specified attribute as it appeared in the target entry before
   * the change was processed, if available.
   *
   * @param  name  The name of the attribute to retrieve as it appeared before
   *               the change.
   *
   * @return  The requested attribute as it appeared in the target entry before
   *          the change was processed, or {@code null} if it was not available
   *          in the changelog entry.
   *
   * @throws  ChangeLogEntryAttributeExceededMaxValuesException  If the
   *               specified attribute had more values before the change than
   *               may be included in a changelog entry.
   */
  public Attribute getAttributeBeforeChange(final String name)
         throws ChangeLogEntryAttributeExceededMaxValuesException
  {
    if (getChangeType() == ChangeType.ADD)
    {
      return null;
    }

    for (final Attribute a : updatedAttributesBeforeChange)
    {
      if (a.getName().equalsIgnoreCase(name))
      {
        return a;
      }
    }

    for (final ChangeLogEntryAttributeExceededMaxValuesCount a :
         attributesThatExceededMaxValuesCount)
    {
      if (a.getAttributeName().equalsIgnoreCase(name))
      {
        // TODO:  In the event that the before count was exceeded but the after
        // count was not, then we may be able to reconstruct the before values
        // if the changes included deleting specific values for the attribute.
        throw new ChangeLogEntryAttributeExceededMaxValuesException(
             ERR_CHANGELOG_EXCEEDED_BEFORE_VALUE_COUNT.get(name, getTargetDN(),
                  a.getBeforeCount()),
             a);
      }
    }

    for (final Attribute a : keyEntryAttributes)
    {
      if (a.getName().equalsIgnoreCase(name))
      {
        return a;
      }
    }

    final List<Attribute> deletedAttrs = getDeletedEntryAttributes();
    if (deletedAttrs != null)
    {
      for (final Attribute a : deletedAttrs)
      {
        if (a.getName().equalsIgnoreCase(name))
        {
          return a;
        }
      }
    }

    return null;
  }



  /**
   * Retrieves the specified attribute as it appeared in the target entry after
   * the change was processed, if available.
   *
   * @param  name  The name of the attribute to retrieve as it appeared after
   *               the change.
   *
   * @return  The requested attribute as it appeared in the target entry after
   *          the change was processed, or {@code null} if it was not available
   *          in the changelog entry.
   *
   * @throws  ChangeLogEntryAttributeExceededMaxValuesException  If the
   *               specified attribute had more values before the change than
   *               may be included in a changelog entry.
   */
  public Attribute getAttributeAfterChange(final String name)
         throws ChangeLogEntryAttributeExceededMaxValuesException
  {
    if (getChangeType() == ChangeType.DELETE)
    {
      return null;
    }

    for (final Attribute a : updatedAttributesAfterChange)
    {
      if (a.getName().equalsIgnoreCase(name))
      {
        return a;
      }
    }

    for (final Attribute a : keyEntryAttributes)
    {
      if (a.getName().equalsIgnoreCase(name))
      {
        return a;
      }
    }

    for (final ChangeLogEntryAttributeExceededMaxValuesCount a :
         attributesThatExceededMaxValuesCount)
    {
      if (a.getAttributeName().equalsIgnoreCase(name))
      {
        // TODO:  In the event that the after count was exceeded but the before
        // count was not, then we may be able to reconstruct the after values
        // if the changes included adding specific values for the attribute.
        throw new ChangeLogEntryAttributeExceededMaxValuesException(
             ERR_CHANGELOG_EXCEEDED_AFTER_VALUE_COUNT.get(name, getTargetDN(),
                  a.getAfterCount()),
             a);
      }
    }

    final List<Attribute> addAttrs = getAddAttributes();
    if (addAttrs != null)
    {
      for (final Attribute a : addAttrs)
      {
        if (a.getName().equalsIgnoreCase(name))
        {
          return a;
        }
      }
    }

    final List<Modification> mods = getModifications();
    if (mods != null)
    {
      for (final Modification m : mods)
      {
        if (m.getAttributeName().equalsIgnoreCase(name))
        {
          final byte[][] values = m.getValueByteArrays();
          if ((m.getModificationType() == ModificationType.REPLACE) &&
              (values.length > 0))
          {
            return new Attribute(name, values);
          }
        }
      }
    }

    return null;
  }



  /**
   * Attempts to construct a partial representation of the target entry as it
   * appeared before the change was processed.  The information contained in the
   * constructed entry will be based solely on information contained in the
   * changelog entry, including information provided in the deletedEntryAttrs,
   * ds-changelog-before-values, ds-changelog-after-values,
   * ds-changelog-entry-key-attr-values, and
   * ds-changelog-attr-exceeded-max-values-count attributes.
   *
   * @return  A partial representation of the target entry as it appeared before
   *          the change was processed, or {@code null} if the change was an
   *          add operation and therefore the entry did not exist before the
   *          change.
   */
  public ReadOnlyEntry constructPartialEntryBeforeChange()
  {
    if (getChangeType() == ChangeType.ADD)
    {
      return null;
    }

    final Entry e = new Entry(getTargetDN());

    // If there is a set of deleted entry attributes available, then use them.
    final List<Attribute> deletedEntryAttrs = getDeletedEntryAttributes();
    if (deletedEntryAttrs != null)
    {
      for (final Attribute a : deletedEntryAttrs)
      {
        e.addAttribute(a);
      }
    }

    // If there is a set of before attributes, then use them.
    for (final Attribute a : updatedAttributesBeforeChange)
    {
      if (! e.hasAttribute(a.getName()))
      {
        e.addAttribute(a);
      }
    }

    // If there is a set of key attributes, then only use them if the
    // associated attributes aren't already in the entry and aren't in either
    // the after values and exceeded max values count.
    for (final Attribute a : keyEntryAttributes)
    {
      boolean shouldExclude = e.hasAttribute(a.getName());

      for (final Attribute ba : updatedAttributesAfterChange)
      {
        if (ba.getName().equalsIgnoreCase(a.getName()))
        {
          shouldExclude = true;
        }
      }

      for (final ChangeLogEntryAttributeExceededMaxValuesCount ea :
           attributesThatExceededMaxValuesCount)
      {
        if (ea.getAttributeName().equalsIgnoreCase(a.getName()))
        {
          // TODO:  In the event that the before count was exceeded but the
          // after count was not, then we may be able to reconstruct the before
          // values if the changes included deleting specific values for the
          // attribute.
          shouldExclude = true;
        }
      }

      if (! shouldExclude)
      {
        e.addAttribute(a);
      }
    }

    // NOTE:  Although we could possibly get additional attribute values from
    // the entry's RDN, that can't be considered authoritative because those
    // same attributes may have additional values that aren't in the RDN, and we
    // don't want to include an attribute without the entire set of values.

    return new ReadOnlyEntry(e);
  }



  /**
   * Attempts to construct a partial representation of the target entry as it
   * appeared after the change was processed.  The information contained in the
   * constructed entry will be based solely on information contained in the
   * changelog entry, including information provided in the changes,
   * ds-changelog-after-values, and ds-changelog-entry-key-attr-values
   * attributes.
   *
   * @return  A partial representation of the target entry as it appeared after
   *          the change was processed, or {@code null} if the change was a
   *          delete operation and therefore did not exist after the change.
   */
  public ReadOnlyEntry constructPartialEntryAfterChange()
  {
    final Entry e;
    switch (getChangeType())
    {
      case ADD:
      case MODIFY:
        e = new Entry(getTargetDN());
        break;

      case MODIFY_DN:
        e = new Entry(getNewDN());
        break;

      case DELETE:
      default:
        return null;
    }


    // If there is a set of add attributes, then use them.
    final List<Attribute> addAttrs = getAddAttributes();
    if (addAttrs != null)
    {
      for (final Attribute a : addAttrs)
      {
        e.addAttribute(a);
      }
    }

    // If there is a set of modifications and any of them are replace
    // modifications with a set of values, then we can use them to determine
    // the new values of those attributes.
    final List<Modification> mods = getModifications();
    if (mods != null)
    {
      for (final Modification m : mods)
      {
        final byte[][] values = m.getValueByteArrays();
        if ((m.getModificationType() == ModificationType.REPLACE) &&
            (values.length > 0))
        {
          e.addAttribute(m.getAttributeName(), values);
        }
      }
    }

    // If there is a set of after attributes, then use them.
    for (final Attribute a : updatedAttributesAfterChange)
    {
      if (! e.hasAttribute(a.getName()))
      {
        e.addAttribute(a);
      }
    }

    // If there is a set of key attributes, then use them.
    for (final Attribute a : keyEntryAttributes)
    {
      if (! e.hasAttribute(a.getName()))
      {
        e.addAttribute(a);
      }
    }

    // TODO:  In the event that the after count was exceeded but the before
    // count was not, then we may be able to reconstruct the after values if the
    // changes included adding specific values for the attribute.

    // NOTE:  Although we could possibly get additional attribute values from
    // the entry's RDN, that can't be considered authoritative because those
    // same attributes may have additional values that aren't in the RDN, and we
    // don't want to include an attribute without the entire set of values.

    return new ReadOnlyEntry(e);
  }
}
