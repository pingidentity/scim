/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.controls;



import com.unboundid.asn1.ASN1OctetString;
import com.unboundid.ldap.sdk.Control;
import com.unboundid.ldap.sdk.DecodeableControl;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;

import static com.unboundid.ldap.sdk.unboundidds.controls.ControlMessages.*;



/**
 * This class provides an implementation of the unsolicited cancel response
 * control, which may be returned by the Directory Server if an operation is
 * canceled by the server without a cancel or abandon request from the client.
 * This control does not have a value.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class UnsolicitedCancelResponseControl
       extends Control
       implements DecodeableControl
{
  /**
   * The OID (1.3.6.1.4.1.30221.2.5.7) for the unsolicited cancel response
   * control.
   */
  public static final String UNSOLICITED_CANCEL_RESPONSE_OID =
       "1.3.6.1.4.1.30221.2.5.7";



  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 36962888392922937L;



  /**
   * Creates a new unsolicited cancel response control.
   */
  public UnsolicitedCancelResponseControl()
  {
    super(UNSOLICITED_CANCEL_RESPONSE_OID, false, null);
  }



  /**
   * Creates a new account usable response control with the provided
   * information.
   *
   * @param  oid         The OID for the control.
   * @param  isCritical  Indicates whether the control should be marked
   *                     critical.
   * @param  value       The encoded value for the control.  This may be
   *                     {@code null} if no value was provided.
   *
   * @throws  LDAPException  If the provided control cannot be decoded as an
   *                         account usable response control.
   */
  public UnsolicitedCancelResponseControl(final String oid,
                                          final boolean isCritical,
                                          final ASN1OctetString value)
         throws LDAPException
  {
    super(oid, isCritical,  value);

    if (value != null)
    {
      throw new LDAPException(ResultCode.DECODING_ERROR,
                              ERR_UNSOLICITED_CANCEL_RESPONSE_HAS_VALUE.get());
    }
  }



  /**
   * {@inheritDoc}
   */
  public UnsolicitedCancelResponseControl decodeControl(final String oid,
                                               final boolean isCritical,
                                               final ASN1OctetString value)
         throws LDAPException
  {
    return new UnsolicitedCancelResponseControl(oid, isCritical, value);
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public String getControlName()
  {
    return INFO_CONTROL_NAME_UNSOLICITED_CANCEL_RESPONSE.get();
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public void toString(final StringBuilder buffer)
  {
    buffer.append("UnsolicitedCancelResponseControl()");
  }
}
