/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This enum defines the set of access log operation types.
 */
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public enum AccessLogOperationType
{
  /**
   * The operation type that will be used for messages about abandon operations.
   */
  ABANDON("ABANDON"),



  /**
   * The operation type that will be used for messages about add operations.
   */
  ADD("ADD"),



  /**
   * The operation type that will be used for messages about bind operations.
   */
  BIND("BIND"),



  /**
   * The operation type that will be used for messages about compare operations.
   */
  COMPARE("COMPARE"),



  /**
   * The operation type that will be used for messages about delete operations.
   */
  DELETE("DELETE"),



  /**
   * The operation type that will be used for messages about extended
   * operations.
   */
  EXTENDED("EXTENDED"),



  /**
   * The operation type that will be used for messages about modify operations.
   */
  MODIFY("MODIFY"),



  /**
   * The operation type that will be used for messages about modify DN
   * operations.
   */
  MODDN("MODDN"),



  /**
   * The operation type that will be used for messages about search operations.
   */
  SEARCH("SEARCH"),



  /**
   * The operation type that will be used for messages about unbind operations.
   */
  UNBIND("UNBIND");



  // The string that will be used to identify this message type in log files.
  private final String logIdentifier;



  /**
   * Creates a new access log operation type with the provided information.
   *
   * @param  logIdentifier  The string that will be used to identify this
   *                        operation type in log files.
   */
  private AccessLogOperationType(final String logIdentifier)
  {
    this.logIdentifier = logIdentifier;
  }



  /**
   * Retrieves the string that will be used to identify this operation type in
   * log files.
   *
   * @return  The string that will be used to identify this operation type in
   *          log files.
   */
  public String getLogIdentifier()
  {
    return logIdentifier;
  }



  /**
   * Retrieves the access log operation type with the provided identifier.
   *
   * @param  logIdentifier  The identifier string for which to retrieve the
   *                        corresponding access log operation type.
   *
   * @return  The appropriate operation type, or {@code null} if there is no
   *          operation type associated with the provided identifier.
   */
  public static AccessLogOperationType forName(final String logIdentifier)
  {
    for (final AccessLogOperationType t : values())
    {
      if (t.getLogIdentifier().equals(logIdentifier))
      {
        return t;
      }
    }

    return null;
  }
}
