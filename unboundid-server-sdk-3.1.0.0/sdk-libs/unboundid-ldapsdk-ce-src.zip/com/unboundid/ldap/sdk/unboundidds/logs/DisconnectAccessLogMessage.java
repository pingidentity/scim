/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about a
 * connection that has been closed.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class DisconnectAccessLogMessage
       extends AccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -6224280874144845557L;



  // The message providing additional information about the disconnect.
  private final String message;

  // The reason for the disconnect.
  private final String reason;



  /**
   * Creates a new disconnect access log message from the provided message
   * string.
   *
   * @param  s  The string to be parsed as a disconnect access log message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public DisconnectAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new disconnect access log message from the provided log message.
   *
   * @param  m  The log message to be parsed as a disconnect access log message.
   */
  public DisconnectAccessLogMessage(final LogMessage m)
  {
    super(m);

    reason  = getNamedValue("reason");
    message = getNamedValue("msg");
  }



  /**
   * Retrieves the disconnect reason for the log message.
   *
   * @return  The disconnect reason for the log message, or {@code null} if it
   *          is not included in the log message.
   */
  public String getDisconnectReason()
  {
    return reason;
  }



  /**
   * Retrieves a message with additional information about the disconnect.
   *
   * @return  A message with additional information about the disconnect, or
   *          {@code null} if it is not included in the log message.
   */
  public String getMessage()
  {
    return message;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogMessageType getMessageType()
  {
    return AccessLogMessageType.DISCONNECT;
  }
}
