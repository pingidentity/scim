/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import com.unboundid.util.NotExtensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about an
 * operation request received from a client.
 */
@NotExtensible()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public abstract class OperationRequestAccessLogMessage
       extends OperationAccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -8942685623238040482L;



  // The OIDs of the request controls contained in the request.
  private final List<String> requestControlOIDs;

  // Information from the intermediate client request control contained in the
  // request.
  private final String intermediateClientRequest;

  // The DN of the user that requested the message.
  private final String requesterDN;

  // The IP address of the client that requested the message.
  private final String requesterIP;



  /**
   * Creates a new operation request access log message from the provided log
   * message.
   *
   * @param  m  The log message to be parsed as an operation request access log
   *            message.
   */
  protected OperationRequestAccessLogMessage(final LogMessage m)
  {
    super(m);

    intermediateClientRequest = getNamedValue("via");
    requesterDN               = getNamedValue("requesterDN");
    requesterIP               = getNamedValue("requesterIP");

    final String controlStr = getNamedValue("requestControls");
    if (controlStr == null)
    {
      requestControlOIDs = Collections.emptyList();
    }
    else
    {
      final LinkedList<String> controlList = new LinkedList<String>();
      final StringTokenizer t = new StringTokenizer(controlStr, ",");
      while (t.hasMoreTokens())
      {
        controlList.add(t.nextToken());
      }
      requestControlOIDs = Collections.unmodifiableList(controlList);
    }
  }



  /**
   * Retrieves the DN of the user that requested the operation.
   *
   * @return  The DN of the user that requested the operation, or {@code null}
   *          if it is not included in the log message.
   */
  public final String getRequesterDN()
  {
    return requesterDN;
  }



  /**
   * Retrieves the IP address of the client that requested the operation.
   *
   * @return  The IP address of the client that requested the operation, or
   *          {@code null} if it is not included in the log message.
   */
  public final String getRequesterIPAddress()
  {
    return requesterIP;
  }



  /**
   * Retrieves the content of any intermediate client request control contained
   * in the request.
   *
   * @return  The content of any intermediate client request control contained
   *          in the request, or {@code null} if it is not included in the log
   *          message.
   */
  public final String getIntermediateClientRequest()
  {
    return intermediateClientRequest;
  }



  /**
   * Retrieves the OIDs of any request controls contained in the log message.
   *
   * @return  The OIDs of any request controls contained in the log message, or
   *          an empty list if it is not included in the log message.
   */
  public final List<String> getRequestControlOIDs()
  {
    return requestControlOIDs;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public AccessLogMessageType getMessageType()
  {
    return AccessLogMessageType.REQUEST;
  }
}
