/*
 * Copyright 2009-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.logs;



import com.unboundid.util.NotExtensible;
import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a data structure that holds information about a log
 * message that may appear in the Directory Server access log about an abandon
 * request received from a client.
 */
@NotExtensible()
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public class AbandonRequestAccessLogMessage
       extends OperationRequestAccessLogMessage
{
  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = 4681707907192987394L;



  // The message ID of the operation to abandon.
  private final Integer idToAbandon;



  /**
   * Creates a new abandon request access log message from the provided message
   * string.
   *
   * @param  s  The string to be parsed as an abandon request access log
   *            message.
   *
   * @throws  LogException  If the provided string cannot be parsed as a valid
   *                        log message.
   */
  public AbandonRequestAccessLogMessage(final String s)
         throws LogException
  {
    this(new LogMessage(s));
  }



  /**
   * Creates a new abandon request access log message from the provided log
   * message.
   *
   * @param  m  The log message to be parsed as an abandon request access log
   *            message.
   */
  public AbandonRequestAccessLogMessage(final LogMessage m)
  {
    super(m);

    idToAbandon = getNamedValueAsInteger("idToAbandon");
  }



  /**
   * Retrieves the message ID of the operation that should be abandoned.
   *
   * @return  The message ID of the operation that should be abandoned, or
   *          {@code null} if it is not included in the log message.
   */
  public final Integer getMessageIDToAbandon()
  {
    return idToAbandon;
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public final AccessLogOperationType getOperationType()
  {
    return AccessLogOperationType.ABANDON;
  }
}
