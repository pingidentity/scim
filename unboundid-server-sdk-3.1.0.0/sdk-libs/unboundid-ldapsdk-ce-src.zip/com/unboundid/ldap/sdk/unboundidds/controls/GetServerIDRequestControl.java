/*
 * Copyright 2008-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.controls;



import com.unboundid.ldap.sdk.Control;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.util.NotMutable;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;

import static com.unboundid.ldap.sdk.unboundidds.controls.ControlMessages.*;



/**
 * This class provides a request control which may be used to request the server
 * ID of the server that actually processed the associated request.  It may be
 * used for requests sent directly to a Directory Server, but it is more useful
 * when the request will pass through a Directory Proxy Server instance because
 * the corresponding {@link GetServerIDResponseControl} will provide the server
 * ID of the backend server used to process the request.  This server ID may be
 * used in a {@link RouteToServerRequestControl} instance to request that
 * subsequent operations be processed by the same server.
 * <BR><BR>
 * This control does not have a value.  The criticality may be either
 * {@code true} or {@code false}.
 */
@NotMutable()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class GetServerIDRequestControl
       extends Control
{
  /**
   * The OID (1.3.6.1.4.1.30221.2.5.14) for the get server ID request control.
   */
  public static final String GET_SERVER_ID_REQUEST_OID =
       "1.3.6.1.4.1.30221.2.5.14";


  /**
   * The serial version UID for this serializable class.
   */
  private static final long serialVersionUID = -6015835755174298354L;



  /**
   * Creates a new get server ID request control.  It will not be marked
   * critical.
   */
  public GetServerIDRequestControl()
  {
    this(false);
  }



  /**
   * Creates a new get server ID request control with the specified
   * criticality.
   *
   * @param  isCritical  Indicates whether this control should be marked
   *                     critical.
   */
  public GetServerIDRequestControl(final boolean isCritical)
  {
    super(GET_SERVER_ID_REQUEST_OID, isCritical,  null);
  }



  /**
   * Creates a new get server ID request control which is decoded from the
   * provided generic control.
   *
   * @param  control  The generic control to be decoded as a get server ID
   *                  request control.
   *
   * @throws  LDAPException  If the provided control cannot be decoded as a get
   *                         server ID request control.
   */
  public GetServerIDRequestControl(final Control control)
         throws LDAPException
  {
    super(control);

    if (control.hasValue())
    {
      throw new LDAPException(ResultCode.DECODING_ERROR,
                              ERR_GET_SERVER_ID_REQUEST_HAS_VALUE.get());
    }
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public String getControlName()
  {
    return INFO_CONTROL_NAME_GET_SERVER_ID_REQUEST.get();
  }



  /**
   * {@inheritDoc}
   */
  @Override()
  public void toString(final StringBuilder buffer)
  {
    buffer.append("GetServerIDRequestControl(isCritical=");
    buffer.append(isCritical());
    buffer.append(')');
  }
}
