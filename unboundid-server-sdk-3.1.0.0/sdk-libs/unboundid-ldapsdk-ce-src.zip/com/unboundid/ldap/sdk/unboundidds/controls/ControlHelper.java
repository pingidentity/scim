/*
 * Copyright 2007-2011 UnboundID Corp.
 * All Rights Reserved.
 */
package com.unboundid.ldap.sdk.unboundidds.controls;



import com.unboundid.ldap.sdk.Control;
import com.unboundid.util.InternalUseOnly;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a helper class that may be used to ensure that all of the
 * "out-of-the-box" UnboundID-specific response controls supported by this SDK
 * are registered so that they can be properly instantiated when received in a
 * response from the directory server.
 */
@InternalUseOnly()
@ThreadSafety(level=ThreadSafetyLevel.COMPLETELY_THREADSAFE)
public final class ControlHelper
{
  /**
   * Prevent this class from being instantiated.
   */
  private ControlHelper()
  {
    // No implementation is required.
  }



  /**
   * Registers all "out-of-the-box" response UnboundID-specific controls
   * provided with this SDK so that they may be properly decoded if they are
   * received in an LDAP response.  This method is intended only for internal
   * use only and should not be called by external applications.
   */
  @InternalUseOnly()
  public static void registerDefaultResponseControls()
  {
    Control.registerDecodeableControl(
         AccountUsableResponseControl.ACCOUNT_USABLE_RESPONSE_OID,
         new AccountUsableResponseControl());

    Control.registerDecodeableControl(
         GetAuthorizationEntryResponseControl.
              GET_AUTHORIZATION_ENTRY_RESPONSE_OID,
         new GetAuthorizationEntryResponseControl());

    Control.registerDecodeableControl(
         GetServerIDResponseControl.GET_SERVER_ID_RESPONSE_OID,
         new GetServerIDResponseControl());

    Control.registerDecodeableControl(
         IntermediateClientResponseControl.INTERMEDIATE_CLIENT_RESPONSE_OID,
         new IntermediateClientResponseControl());

    Control.registerDecodeableControl(
         InteractiveTransactionSpecificationResponseControl.
              INTERACTIVE_TRANSACTION_SPECIFICATION_RESPONSE_OID,
         new InteractiveTransactionSpecificationResponseControl());

    Control.registerDecodeableControl(
         JoinResultControl.JOIN_RESULT_OID,
         new JoinResultControl());

    Control.registerDecodeableControl(
         PasswordPolicyResponseControl.PASSWORD_POLICY_RESPONSE_OID,
         new PasswordPolicyResponseControl());

    Control.registerDecodeableControl(
         UnsolicitedCancelResponseControl.UNSOLICITED_CANCEL_RESPONSE_OID,
         new UnsolicitedCancelResponseControl());
  }
}
