/*
 * Copyright 2007-2011 UnboundID Corp.
 * All Rights Reserved.
 */



/**
 * This package contains implementations for a number of LDAP extended
 * operations which are specific to the UnboundID Directory Server.  In some
 * cases, they may be based on standard extended operations which have not yet
 * reached a sufficient stability level to make them available for general use
 * against any kind of server, while in other cases they may be defined
 * specifically for use with the UnboundID Directory Server.
 */
package com.unboundid.ldap.sdk.unboundidds.extensions;
