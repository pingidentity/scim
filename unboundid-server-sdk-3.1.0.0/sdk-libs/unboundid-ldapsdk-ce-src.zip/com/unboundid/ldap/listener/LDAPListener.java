/*
 * Copyright 2010-2011 UnboundID Corp.
 * All Rights Reserved.
 */
/*
 * Copyright (C) 2010-2011 UnboundID Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (GPLv2 only)
 * or the terms of the GNU Lesser General Public License (LGPLv2.1 only)
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses>.
 */
package com.unboundid.ldap.listener;



import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.ServerSocketFactory;

import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.util.Debug;
import com.unboundid.util.InternalUseOnly;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This class provides a mechanism that may be used to accept connections from
 * LDAP clients and ensure that any requests received on those connections will
 * be processed appropriately.
 */
@ThreadSafety(level=ThreadSafetyLevel.NOT_THREADSAFE)
public final class LDAPListener
       extends Thread
{
  // Indicates whether a request has been received to stop running.
  private final AtomicBoolean stopRequested;

  // The connection ID value that should be assigned to the next connection that
  // is established.
  private final AtomicLong nextConnectionID;

  // The server socket that is being used to accept connections.
  private final AtomicReference<ServerSocket> serverSocket;

  // The thread that is currently listening for new client connections.
  private final AtomicReference<Thread> thread;

  // A map of all established connections.
  private final ConcurrentHashMap<Long,LDAPListenerClientConnection>
       establishedConnections;

  // The latch used to wait for the listener to have started.
  private final CountDownLatch startLatch;

  // The configuration to use for this listener.
  private final LDAPListenerConfig config;



  /**
   * Creates a new {@code LDAPListener} object with the provided configuration.
   * The {@link #start} method must be called after creating the object to
   * actually start listening for requests.
   *
   * @param  config  The configuration to use for this listener.
   */
  public LDAPListener(final LDAPListenerConfig config)
  {
    this.config = config.duplicate();

    stopRequested = new AtomicBoolean(false);
    nextConnectionID = new AtomicLong(0L);
    serverSocket = new AtomicReference<ServerSocket>(null);
    thread = new AtomicReference<Thread>(null);
    startLatch = new CountDownLatch(1);
    establishedConnections =
         new ConcurrentHashMap<Long,LDAPListenerClientConnection>();
    setName("LDAP Listener Thread (not listening");
  }



  /**
   * Creates the server socket for this listener and starts listening for client
   * connections.  This method will return after the listener has stated.
   *
   * @throws  IOException  If a problem occurs while creating the server socket.
   */
  public void startListening()
         throws IOException
  {
    final ServerSocketFactory f = config.getServerSocketFactory();
    final InetAddress a = config.getListenAddress();
    final int p = config.getListenPort();
    if (a == null)
    {
      serverSocket.set(f.createServerSocket(config.getListenPort(), 128));
    }
    else
    {
      serverSocket.set(f.createServerSocket(config.getListenPort(), 128, a));
    }

    final int receiveBufferSize = config.getReceiveBufferSize();
    if (receiveBufferSize > 0)
    {
      serverSocket.get().setReceiveBufferSize(receiveBufferSize);
    }

    setName("LDAP Listener Thread (listening on port " +
         serverSocket.get().getLocalPort() + ')');

    start();

    try
    {
      startLatch.await();
    }
    catch (final Exception e)
    {
      Debug.debugException(e);
    }
  }



  /**
   * Operates in a loop, waiting for client connections to arrive and ensuring
   * that they are handled properly.  This method is for internal use only and
   * must not be called by third-party code.
   */
  @InternalUseOnly()
  @Override()
  public void run()
  {
    thread.set(Thread.currentThread());
    final LDAPListenerExceptionHandler exceptionHandler =
         config.getExceptionHandler();

    try
    {
      startLatch.countDown();
      while (! stopRequested.get())
      {
        final Socket s;
        try
        {
          s = serverSocket.get().accept();
        }
        catch (final Exception e)
        {
          Debug.debugException(e);

          if (exceptionHandler != null)
          {
            exceptionHandler.connectionCreationFailure(null, e);
          }

          continue;
        }


        final LDAPListenerClientConnection c;
        try
        {
          c = new LDAPListenerClientConnection(this, s,
               config.getRequestHandler(), config.getExceptionHandler());
        }
        catch (final LDAPException le)
        {
          Debug.debugException(le);

          if (exceptionHandler != null)
          {
            exceptionHandler.connectionCreationFailure(s, le);
          }

          continue;
        }

        establishedConnections.put(c.getConnectionID(), c);
        c.start();
      }
    }
    finally
    {
      final ServerSocket s = serverSocket.getAndSet(null);
      if (s != null)
      {
        try
        {
          s.close();
        }
        catch (final Exception e)
        {
          Debug.debugException(e);
        }
      }

      serverSocket.set(null);
      thread.set(null);
    }
  }



  /**
   * Indicates that this listener should stop accepting connections.  It may
   * optionally also terminate any existing connections that are already
   * established.
   *
   * @param  closeExisting  Indicates whether to close existing connections that
   *                        may already be established.
   */
  public void shutDown(final boolean closeExisting)
  {
    stopRequested.set(true);

    final ServerSocket s = serverSocket.get();
    if (s != null)
    {
      try
      {
        s.close();
      }
      catch (final Exception e)
      {
        Debug.debugException(e);
      }
    }

    final Thread t = thread.get();
    if (t != null)
    {
      while (t.isAlive())
      {
        try
        {
          t.join(100L);
        }
        catch (final Exception e)
        {
          Debug.debugException(e);
        }

        if (t.isAlive())
        {

          try
          {
            t.interrupt();
          }
          catch (final Exception e)
          {
            Debug.debugException(e);
          }
        }
      }
    }

    if (closeExisting)
    {
      final ArrayList<LDAPListenerClientConnection> connList =
           new ArrayList<LDAPListenerClientConnection>(
                establishedConnections.values());
      for (final LDAPListenerClientConnection c : connList)
      {
        try
        {
          c.close();
        }
        catch (final Exception e)
        {
          Debug.debugException(e);
        }
      }
    }
  }



  /**
   * Retrieves the address on which this listener is accepting client
   * connections.  Note that if no explicit listen address was configured, then
   * the address returned may not be usable by clients.  In the event that the
   * {@code InetAddress.isAnyLocalAddress} method returns {@code true}, then
   * clients should generally use {@code localhost} to attempt to establish
   * connections.
   *
   * @return  The address on which this listener is accepting client
   *          connections, or {@code null} if it is not currently listening for
   *          client connections.
   */
  public InetAddress getListenAddress()
  {
    final ServerSocket s = serverSocket.get();
    if (s == null)
    {
      return null;
    }
    else
    {
      return s.getInetAddress();
    }
  }



  /**
   * Retrieves the port on which this listener is accepting client connections.
   *
   * @return  The port on which this listener is accepting client connections,
   *          or -1 if it is not currently listening for client connections.
   */
  public int getListenPort()
  {
    final ServerSocket s = serverSocket.get();
    if (s == null)
    {
      return -1;
    }
    else
    {
      return s.getLocalPort();
    }
  }



  /**
   * Retrieves the configuration in use for this listener.  It must not be
   * altered in any way.
   *
   * @return  The configuration in use for this listener.
   */
  LDAPListenerConfig getConfig()
  {
    return config;
  }



  /**
   * Retrieves the connection ID that should be used for the next connection
   * accepted by this listener.
   *
   * @return  The connection ID that should be used for the next connection
   *          accepted by this listener.
   */
  long nextConnectionID()
  {
    return nextConnectionID.getAndIncrement();
  }



  /**
   * Indicates that the provided client connection has been closed and is no
   * longer listening for client connections.
   *
   * @param  connection  The connection that has been closed.
   */
  void connectionClosed(final LDAPListenerClientConnection connection)
  {
    establishedConnections.remove(connection.getConnectionID());
  }
}
