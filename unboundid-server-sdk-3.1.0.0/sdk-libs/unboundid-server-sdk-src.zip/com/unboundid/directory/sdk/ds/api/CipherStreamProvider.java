/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.ds.api;



import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

import com.unboundid.directory.sdk.common.internal.ExampleUsageProvider;
import com.unboundid.directory.sdk.common.internal.Reconfigurable;
import com.unboundid.directory.sdk.common.internal.UnboundIDExtension;
import com.unboundid.directory.sdk.ds.config.CipherStreamProviderConfig;
import com.unboundid.directory.sdk.ds.types.DirectoryServerContext;
import com.unboundid.directory.sdk.ds.internal.DirectoryServerExtension;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.util.Extensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;
import com.unboundid.util.args.ArgumentException;
import com.unboundid.util.args.ArgumentParser;



/**
 * This class defines an API that must be implemented by extensions which
 * provide access to cipher input streams and cipher output streams to be used
 * by the server in order to read and write encrypted data.
 * <BR>
 * <H2>Configuring Certificate Mappers</H2>
 * In order to configure a certificate mapper created using this API, use a
 * command like:
 * <PRE>
 *      dsconfig create-cipher-stream-provider \
 *           --provider-name "<I>{provider-name}</I>" \
 *           --type third-party \
 *           --set enabled:true \
 *           --set "extension-class:<I>{class-name}</I>" \
 *           --set "extension-argument:<I>{name=value}</I>"
 * </PRE>
 * where "<I>{provider-name}</I>" is the name to use for the cipher stream
 * provider instance, "<I>{class-name}</I>" is the fully-qualified name of the
 * Java class that extends
 * {@code com.unboundid.directory.sdk.ds.api.CipherStreamProvider},
 * and "<I>{name=value}</I>" represents name-value pairs for any arguments to
 * provide to the cipher stream provider.  If multiple arguments should be
 * provided to the cipher stream provider, then the
 * "<CODE>--set extension-argument:<I>{name=value}</I></CODE>" option should be
 * provided multiple times.
 */
@Extensible()
@DirectoryServerExtension()
@ThreadSafety(level=ThreadSafetyLevel.INTERFACE_THREADSAFE)
public abstract class CipherStreamProvider
       implements UnboundIDExtension,
                  Reconfigurable<CipherStreamProviderConfig>,
                  ExampleUsageProvider
{
  /**
   * Creates a new instance of this cipher stream provider.  All cipher stream
   * provider implementations must include a default constructor, but any
   * initialization should generally be done in the
   * {@code initializeCipherStreamProvider} method.
   */
  public CipherStreamProvider()
  {
    // No implementation is required.
  }



  /**
   * {@inheritDoc}
   */
  public abstract String getExtensionName();



  /**
   * {@inheritDoc}
   */
  public abstract String[] getExtensionDescription();



  /**
   * {@inheritDoc}
   */
  public void defineConfigArguments(final ArgumentParser parser)
         throws ArgumentException
  {
    // No arguments will be allowed by default.
  }



  /**
   * Initializes this cipher stream provider.
   *
   * @param  serverContext  A handle to the server context for the server in
   *                        which this extension is running.
   * @param  config         The general configuration for this cipher stream
   *                        provider.
   * @param  parser         The argument parser which has been initialized from
   *                        the configuration for this cipher stream provider.
   *
   * @throws  LDAPException  If a problem occurs while initializing this cipher
   *                         stream provider.
   */
  public void initializeCipherStreamProvider(
                   final DirectoryServerContext serverContext,
                   final CipherStreamProviderConfig config,
                   final ArgumentParser parser)
         throws LDAPException
  {
    // No initialization will be performed by default.
  }



  /**
   * {@inheritDoc}
   */
  public boolean isConfigurationAcceptable(
                      final CipherStreamProviderConfig config,
                      final ArgumentParser parser,
                      final List<String> unacceptableReasons)
  {
    // No extended validation will be performed by default.
    return true;
  }



  /**
   * {@inheritDoc}
   */
  public ResultCode applyConfiguration(final CipherStreamProviderConfig config,
                                       final ArgumentParser parser,
                                       final List<String> adminActionsRequired,
                                       final List<String> messages)
  {
    // By default, no configuration changes will be applied.  If there are any
    // arguments, then add an admin action message indicating that the extension
    // needs to be restarted for any changes to take effect.
    if (! parser.getNamedArguments().isEmpty())
    {
      adminActionsRequired.add(
           "No configuration change has actually been applied.  The new " +
                "configuration will not take effect until this cipher stream " +
                "provider is disabled and re-enabled or until the server is " +
                "restarted.");
    }

    return ResultCode.SUCCESS;
  }



  /**
   * Performs any cleanup which may be necessary when this cipher stream
   * provider is to be taken out of service.
   */
  public void finalizeCipherStreamProvider()
  {
    // No implementation is required.
  }



  /**
   * Wraps the provided input stream in a cipher input stream that can be used
   * to decrypt data read from the given stream.
   *
   * @param  source  The input stream to be wrapped with a cipher input stream.
   *
   * @return  The cipher input stream which wraps the provided input stream.
   *
   * @throws  LDAPException  If a problem occurs while creating the cipher input
   *                         stream.
   */
  public abstract CipherInputStream createCipherInputStream(
                                         final InputStream source)
         throws LDAPException;



  /**
   * Wraps the provided output stream in a cipher output stream that can be used
   * to encrypt data written to the given stream.
   *
   * @param  target  The output stream to be wrapped with a cipher output
   *                 stream.
   *
   * @return  The cipher output stream which wraps the provided output stream.
   *
   * @throws  LDAPException  If a problem occurs while creating the cipher
   *                         output stream.
   */
  public abstract CipherOutputStream createCipherOutputStream(
                                          final OutputStream target)
         throws LDAPException;



  /**
   * {@inheritDoc}
   */
  public Map<List<String>,String> getExamplesArgumentSets()
  {
    return Collections.emptyMap();
  }
}
