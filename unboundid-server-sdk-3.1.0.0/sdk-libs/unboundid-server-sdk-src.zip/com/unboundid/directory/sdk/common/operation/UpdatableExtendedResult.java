/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * docs/licenses/cddl.txt
 * or http://www.opensource.org/licenses/cddl1.php.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * docs/licenses/cddl.txt.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2010-2011 UnboundID Corp.
 */
package com.unboundid.directory.sdk.common.operation;



import com.unboundid.asn1.ASN1OctetString;
import com.unboundid.ldap.sdk.LDAPResult;
import com.unboundid.util.NotExtensible;
import com.unboundid.util.ThreadSafety;
import com.unboundid.util.ThreadSafetyLevel;



/**
 * This interface defines a set of methods which may be used to update extended
 * results.
 */
@NotExtensible()
@ThreadSafety(level=ThreadSafetyLevel.INTERFACE_NOT_THREADSAFE)
public interface UpdatableExtendedResult
       extends ExtendedResult, UpdatableGenericResult
{
  /**
   * Specifies the OID for the extended result, if any.
   *
   * @param  oid  The OID for the extended result.  It may be {@code null} if
   *              there is none.
   */
  void setResultOID(final String oid);



  /**
   * Specifies the value for the extended result, if any.
   *
   * @param  value  The value for the extended result.  It may be {@code null}
   *                if there is none.
   */
  void setResultValue(final ASN1OctetString value);



  /**
   * Sets the contents of this result with information from the provided
   * LDAP result, including the result code, diagnostic message, matched DN,
   * referral URLs, and controls.  If the provided result is also an instance
   * of an LDAP SDK {@code ExtendedResult}, then the response OID and value will
   * also be updated.
   *
   * @param  result  The result to use to update this result.  It must not be
   *                 {@code null}.
   */
  void setResultData(final LDAPResult result);
}
